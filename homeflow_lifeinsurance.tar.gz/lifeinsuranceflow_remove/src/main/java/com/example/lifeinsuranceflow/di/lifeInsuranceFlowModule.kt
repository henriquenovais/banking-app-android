package com.example.lifeinsuranceflow.di

import org.koin.dsl.module

val lifeInsuranceFlowModule = module {
}